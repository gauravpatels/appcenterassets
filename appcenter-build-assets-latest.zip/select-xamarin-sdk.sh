#!/bin/bash
if [ -z "$1" ]; then
  echo "No Xamarin SDK specified."
  exit 0
fi

XAMARIN_SDK=$1

if test "$XAMARIN_SDK" = "6_12_25"; then
  echo "Xamarin iOS SDK not available on agent."
  echo "Running brew update..."
  brew update > /dev/null 2>&1
  echo "Finished brew update."
  brew install --cask xamarin-ios
  exit 0
fi 
if test "$XAMARIN_SDK" = "6_12_24"; then
  echo "Xamarin Android SDK not available on agent."
  echo "Running brew update..."
  brew update > /dev/null 2>&1
  echo "Finished brew update."
  brew install --cask xamarin-android
  brew install mono

  echo "Confirming installation of mono and msbuild"
  echo $(which mono)
  echo $(which msbuild)

  exit 0
fi

echo -e "Error: Unsupported Xamarin SDK version.\n\nAndroid: Xamarin platform is deprecated but App Center still supports the latest Xamarin Android 13.2 - please update to it if you want to continue building your application.\niOS: Xamarin platform is deprecated but App Center still supports the latest Xamarin iOS 16.4 - please update to it if you want to continue building your application."
exit 1