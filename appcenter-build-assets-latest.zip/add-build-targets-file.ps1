# Script for adding file Directory.Build.targets to UWP solution
# to fix incorrect certificate signing in VS version 16.9
# slnpath parameter is the path to .sln file
param([string]$slnpath)

$vsInstance = Get-VSSetupInstance -All -Prerelease | Select-VSSetupInstance -Require 'Microsoft.Component.MSBuild' -Latest
$vsInstallDir = $vsInstance.InstallationPath

if (-not $vsInstallDir) {
    Write-Host '##[debug] could not find Visual Studio installation directory'
}
else {
    $msbuildPath = $vsInstallDir + '\MSBuild\Current\Bin\MSBuild.exe' # VS2019

    $msbuildversion = &$msbuildPath -version -nologo
    Write-Host "##[debug] MSBuild version: $msbuildversion"

    $versionMatch = $msbuildversion -match '(\d+)\.(\d+)'

    if(!$versionMatch) {
        Write-Host '##[debug] could not determine MSBuild version'
    }
    else {
        $majv = $Matches[1]
        $minv = $Matches[2]
        $targetsPath = Join-Path $Env:BUILD_SOURCESDIRECTORY 'Directory.Build.targets'

        $localSlnPath = Join-Path $Env:BUILD_SOURCESDIRECTORY $slnpath

        # in case the solution is within a different folder
        $slnFileExists = Test-Path -Path $localSlnPath -PathType Leaf

        if($slnFileExists) {
            $slnFile = Get-Item $localSlnPath
            $slnDir = $slnFile.DirectoryName
            $targetsPath = Join-Path $slnDir 'Directory.Build.targets'
        }

        $targetsFileExists = Test-Path -Path $targetsPath -PathType Leaf

        if (!$targetsFileExists -and ($majv -ge 16) -and ($minv -ge 9)) {
            # create new Directory.Build.targets file
            $dbtargetcontent = 
@'
<?xml version="1.0" encoding="utf-8"?>
<Project>
    <Target Name="_ValidateSigningCertificate" />
    <Target Name="_RemoveDisposableSigningCertificate" />
</Project>
'@
            Out-File -FilePath $targetsPath -Encoding utf8 -InputObject $dbtargetcontent
            Write-Host '##[debug] created file "Directory.Build.targets" in project'
        }
    }
}