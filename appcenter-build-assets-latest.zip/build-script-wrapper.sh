# bash wrapper script for custom build scripts
# gets two arguments
# first - path to the target script
# second - string of passed env variables: "varName=varValue;varName1=varValue1;..."
# example: sh build-script-wrapper.sh ./scripts/test.sh "foo=foo1;bar=bar1"

script=$1

IFS=';' read -r -a variables <<< "$2"

for variable in "${variables[@]}"
do
  IFS='=' read -r -a parsed <<< "$variable"  
  name=${parsed[0]}
  value=${parsed[1]}
  export $name=$value
done

sh $script