#!/bin/bash

if [ -z "$1" ]; then
  echo "No Configuration specified."
  exit 0
fi

if [ -z "$2" ]; then
  echo "No Platform specified."
  exit 0
fi

CONFIGURATION=$1
PLATFORM=$2

# save and change IFS to add filenames with spaces to array
OLDIFS=$IFS
IFS=$(echo -en "\n\b")
CSPROJ_FILES_TO_FIX=($(grep -L -r -i --include \*.csproj -e "PropertyGroup Condition.*$CONFIGURATION|$PLATFORM" \.))

if [ -z "$CSPROJ_FILES_TO_FIX" ]; then
  # restore IFS
  IFS=$OLDIFS
  echo "No project files need configuration fix."
  exit 0
fi

FIND_PATTERN="<\/PropertyGroup>"

if [ "$CONFIGURATION" == "Debug" ]; then
  REPLACE_PATTERN="<\/PropertyGroup>\
    <PropertyGroup Condition=\" '$\(Configuration\)\|$\(Platform\)\' == '$CONFIGURATION|$PLATFORM' \">\
      <DebugSymbols>true<\/DebugSymbols>\
      <DebugType>full<\/DebugType>\
      <Optimize>false<\/Optimize>\
      <OutputPath>bin\\/$PLATFORM\\/$CONFIGURATION<\/OutputPath>\
      <DefineConstants>DEBUG\;<\/DefineConstants>\
      <ErrorReport>prompt<\/ErrorReport>\
      <WarningLevel>4<\/WarningLevel>\
      <ConsolePause>false<\/ConsolePause>\
      <LangVersion>latest<\/LangVersion>\
    <\/PropertyGroup>"
else
  REPLACE_PATTERN="<\/PropertyGroup>\
    <PropertyGroup Condition=\" '$\(Configuration\)\|$\(Platform\)\' == '$CONFIGURATION|$PLATFORM' \">\
    <Optimize>true<\/Optimize>\
    <OutputPath>bin\\/$PLATFORM\\/$CONFIGURATION<\/OutputPath>\
    <WarningLevel>4<\/WarningLevel>\
    <LangVersion>latest<\/LangVersion>\
    <\/PropertyGroup>"
fi

echo "Will fix <OutputPath> property in files:"
echo ${CSPROJ_FILES_TO_FIX[@]}

for csproj_file in ${CSPROJ_FILES_TO_FIX[@]}
do 
    echo "Add missing configuration to: "$csproj_file

    # only change first occurence
    sed -i '' -e "1,/$FIND_PATTERN/s/$FIND_PATTERN/$REPLACE_PATTERN/" "$csproj_file"
done